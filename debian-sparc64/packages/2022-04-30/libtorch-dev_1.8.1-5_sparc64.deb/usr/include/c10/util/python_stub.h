#pragma once

struct _object;
using PyObject = _object;

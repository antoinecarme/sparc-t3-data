#pragma once
#include <ATen/core/ATenGeneral.h> // for BC reasons
#include <c10/core/Backend.h>
#include <c10/core/ScalarType.h>
